V1｜限制算術位寬與平衡求和
來源：本次 st2_code.zip。src/含完整19檔，original/保留本次原始19檔。
累積版本：V1包含V1到V1的修改；不是三個互不相干的實驗。
修改原則：DOTP4 的四個16-bit signed product改為兩個17-bit pair sum與18-bit final sum，再符號延伸成32-bit；ALU CLZ/CTZ/CPOP計數器由32-bit integer明確限制為6 bits。
數學/結構理由：p0..p3各在−16256..16384，pair在−32512..32768，total在−65024..65536，18-bit有號範圍足夠；更保守地看任意16-bit product，四項和也可由18-bit表示。count始終在0..32，6 bits足夠。
預期影響與限制：工具可能已自行推導相同位寬；平衡求和可能改善深度，但沒有面積保證。
修改檔案：MUL_dotp4.sv, ALU.sv

保留top外部介面、五級邊界、pending/mem_sent與IM/DM握手、load與branch控制、RF名稱/reset/x0/f0、CSR、乘法/浮點各獨立instance。
此工作是原版行為的面積候選重構，未併入先前提出的WB/ID功能修補；相同原版缺陷仍可能存在。等價不代表符合全部作業。
本次未取得官方sim/SDC/lib/netlist；未執行VCS/RTL/SYN/DC/STA/JasperGold，不能宣告2ns、官方測試通過或面積縮減。
Python模型測試不是RTL模擬或形式等價證明；詳見validation.json。

建議執行：
iverilog -g2012 -I src -I tests -s equivalence_tb -o /tmp/st2_v1_eq tests/equivalence_tb.sv
vvp /tmp/st2_v1_eq
（亦可使用課程VCS；只列testbench，避免與include重複編譯module。）
此TB比較原版/候選ALU、FP及CPU可見port的隨機樣本，不代替合法程式與握手序列的官方測試。
將src/*.sv複製到完整課程環境的src/後，使用相同2ns約束依序make rtl_all、make synthesize、make syn_all及make superlint。
另測六個公開程式+hidden、load/branch固定bubble、不同IM/DM延遲、f0及CSR退休。
用area_rpt.txt、timing_max_rpt.txt與六程式總時間計算PPA；確認無slack違規再選面積最小版本。
不要將此研究ZIP直接當作規定學號.tar繳交；它未包含完整課程sim/script/syn環境。

三版累積修改對照：
V1：MUL_dotp4.sv 平衡17/18-bit求和；ALU.sv count限制6-bit。
V2：累積V1；top.sv將四組RF運算元縮成兩組已選運算元，名義減64個跨級state bits。
V3：累積V2；FP_addsub.sv正規化改為16/8/4/2/1分級位移，RNE等其餘運算不變。
原碼行數變少不代表面積小；展開的固定for不是多拍運算。
最小面積如何選：用相同RTL測試、相同tool/library、相同2ns SDC及相同負載逐版合成。
先淘汰功能或時序不過版本，再比較Total cell area；若追求作業PA，還要比較六程式總時間×面積。
V2有明確名義state-bit減量，但綜合器可能早已刪除未使用bits；新MUX也有成本。V3是較深入的結構候選，面積可能更小、相同或更大。
證據分類：本版合成實測=無；數學/結構推導與Python模型檢查=有；面積百分比試算=未提供。
模型PASS只表示寫出的模型比較相符；未將SystemVerilog轉譯後執行，也未完成正式等價證明。
