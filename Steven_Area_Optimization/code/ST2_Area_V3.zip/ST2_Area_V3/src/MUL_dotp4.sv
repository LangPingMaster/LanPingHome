// V1: balanced, range-bounded DOTP4 sum. Four dedicated lane multipliers remain.
module MUL_dotp4(input logic [31:0] a,b,output logic [31:0] y);
 wire signed [15:0] p0=$signed(a[7:0])*$signed(b[7:0]);
 wire signed [15:0] p1=$signed(a[15:8])*$signed(b[15:8]);
 wire signed [15:0] p2=$signed(a[23:16])*$signed(b[23:16]);
 wire signed [15:0] p3=$signed(a[31:24])*$signed(b[31:24]);
 // Signed 16-bit products require at most 17-bit pair sums and 18-bit final sum.
 wire signed [16:0] pair01=$signed({p0[15],p0})+$signed({p1[15],p1});
 wire signed [16:0] pair23=$signed({p2[15],p2})+$signed({p3[15],p3});
 wire signed [17:0] total=$signed({pair01[16],pair01})+$signed({pair23[16],pair23});
 assign y={{14{total[17]}},total};
endmodule
