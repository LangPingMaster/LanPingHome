`include "Reg_PC.sv"
`include "Decoder.sv"
`include "Imm_ext.sv"
`include "Regfile.sv"
`include "Regfile_F.sv"
`include "ALU.sv"
`include "JB_unit.sv"
`include "Controller.sv"
`include "CSR.sv"
`include "LD_filter.sv"


module top(
 input logic clk,rst,im_valid,input logic [31:0] im_read_data,
 output logic im_req,output logic [31:0] im_addr,
 input logic dm_valid,input logic [31:0] dm_read_data,
 output logic dm_req,dm_WEB,output logic [31:0] dm_bit_en,dm_addr,dm_write_data
);
 // Five pipeline stages: IF request -> ID -> EX -> MEM -> WB.
 logic [31:0] pc,next_pc;logic pc_en;
 Reg_PC pc_i(.clk(clk),.rst(rst),.en(pc_en),.next_pc(next_pc),.pc(pc));
 assign im_addr=pc;
 logic pending,dv,ev,mv,wv,mem_sent,load_bubble;
 logic [31:0] di,dpc,epc,eimm,mres,mstore,wres;
 logic [6:0] dop,df7,eop,ef7,mop;logic [2:0] df3,ef3,mf3;
 logic [4:0] dr1,dr2,drd,er1,er2,erd,mrd,wrd;
 logic ds1,ds2,dfs1,dfs2,dwi,dwf,dload,dstore,dbranch,djump;
 logic ewi,ewf,eload,estore,ebranch,ejump,mwi,mwf,mload,mstore_en,wwi,wwf;
 logic [31:0] dimm,ia,ib,fa,fb,eda,edb,ea,eb,alu_y,branch_target;
 logic branch_taken,redirect,mem_hold,can_advance,fetch_ok;
 logic [31:0] csr_y,load_y,mem_result;
 logic [11:0] ecsr;
 Decoder dec(.inst(di),.opcode(dop),.f3(df3),.f7(df7),.rs1(dr1),.rs2(dr2),.rd(drd),.int_src1(ds1),.int_src2(ds2),.fp_src1(dfs1),.fp_src2(dfs2),.int_wr(dwi),.fp_wr(dwf),.mem_rd(dload),.mem_wr(dstore),.branch(dbranch),.jump(djump));
 Imm_ext ie(.inst(di),.imm(dimm));
 Regfile VSD_REG_FILE_I(.clk(clk),.rst(rst),.we(wv&&wwi),.ra(dr1),.rb(dr2),.wa(wrd),.wd(wres),.a(ia),.b(ib));
 Regfile_F VSD_REG_FILE_F(.clk(clk),.rst(rst),.we(wv&&wwf),.ra(dr1),.rb(dr2),.wa(wrd),.wd(wres),.a(fa),.b(fb));
 // EX bypass: newest MEM ALU result, then WB. Never bypass an unfinished load.
 always_comb begin
 ea=eda;eb=edb;
 // V2: integer/FP RF selection is performed at the existing ID->EX boundary.
 if(eop==7'h53) begin
  if(mv&&mwf&&!mload&&mrd==er1) ea=mres;
  else if(wv&&wwf&&wrd==er1) ea=wres;
  if(mv&&mwf&&!mload&&mrd==er2) eb=mres;
  else if(wv&&wwf&&wrd==er2) eb=wres;
 end else begin
  if(ev&&er1!=0 && eop!=7'h6f && eop!=7'h37 && eop!=7'h17 && eop!=7'h73) begin
   if(mv&&mwi&&!mload&&mrd==er1) ea=mres;
   else if(wv&&wwi&&wrd==er1) ea=wres;
  end
  if(eop==7'h27) begin
   if(mv&&mwf&&!mload&&mrd==er2) eb=mres;
   else if(wv&&wwf&&wrd==er2) eb=wres;
  end else if(er2!=0 && (eop==7'h33||eop==7'h0b||eop==7'h23||eop==7'h63)) begin
   if(mv&&mwi&&!mload&&mrd==er2) eb=mres;
   else if(wv&&wwi&&wrd==er2) eb=wres;
  end
 end
 end
 ALU alu_i(.a(ea),.b(eb),.imm(eimm),.pc(epc),.opcode(eop),.f7(ef7),.f3(ef3),.y(alu_y));
 JB_unit jb_i(.pc(epc),.a(ea),.b(eb),.imm(eimm),.opcode(eop),.f3(ef3),.taken(branch_taken),.target(branch_target));
 Controller ctrl_i(.rst(rst),.pending(pending),.dv(dv),.load_bubble(load_bubble),.mem_hold(mem_hold),.ev(ev),.ebranch(ebranch),.ejump(ejump),.branch_taken(branch_taken),.advance(can_advance),.fetch_req(fetch_ok),.redirect(redirect));
 CSR csr_i(.clk(clk),.rst(rst),.retire(wv),.addr(ecsr),.rd(csr_y));
 LD_filter ld_i(.word(dm_read_data),.ofs(mres[1:0]),.f3(mf3),.result(load_y));
always_comb begin
    if (mload) begin
        if (mop == 7'h07)
            mem_result = dm_read_data;  // FLW
        else
            mem_result = load_y;        // 整數 Load
    end
    else begin
        mem_result = mres;              // ALU 結果
    end
end
 // Data-memory request: one-cycle pulse, keep payload stable until valid.
 assign dm_req=mv&&(mload||mstore_en)&&!mem_sent;
 assign dm_WEB=!mstore_en;
 assign dm_addr=mres;
 always_comb begin
 dm_bit_en=32'hffffffff;dm_write_data=mstore;
 case(mf3)
 3'b000:begin dm_bit_en=~(32'hff<<{27'd0,mres[1:0],3'b000});dm_write_data=mstore<<{27'd0,mres[1:0],3'b000};end
 3'b001:begin dm_bit_en=~(32'hffff<<{27'd0,mres[1:0],3'b000});dm_write_data=mstore<<{27'd0,mres[1:0],3'b000};end
 default:begin dm_bit_en=32'h00000000;dm_write_data=mstore;end
 endcase
 if(!mstore_en) dm_bit_en=32'hffffffff;
 end
 assign mem_hold=mv&&(mload||mstore_en)&&!(mem_sent&&dm_valid);
 
 // No new request while a previous fetch is outstanding. The ID slot must be free.
 
 assign im_req=fetch_ok;
 assign pc_en=im_req||redirect;
 assign next_pc=redirect?branch_target:(pc+4);
 // ID -> EX operands; WB bypass fixes read-during-write ambiguity.
 always_ff @(posedge clk or posedge rst) begin
 if(rst) begin
  pending<=0;dv<=0;ev<=0;mv<=0;wv<=0;mem_sent<=0;load_bubble<=0;
  di<=0;dpc<=0;epc<=0;eimm<=0;eda<=0;edb<=0;
  eop<=0;ef7<=0;ef3<=0;ecsr<=0;er1<=0;er2<=0;erd<=0;
  ewi<=0;ewf<=0;eload<=0;estore<=0;ebranch<=0;ejump<=0;
  mres<=0;mstore<=0;mf3<=0;mop<=0;mrd<=0;mwi<=0;mwf<=0;mload<=0;mstore_en<=0;
  wrd<=0;wres<=0;wwi<=0;wwf<=0;
 end else begin
  // WB always retires exactly once; it cannot be held by a MEM stall.
  if(im_req) pending<=1;
  if(im_valid&&pending) begin
   pending<=0;
   if(!redirect) begin dv<=1;di<=im_read_data;dpc<=pc-4;end
  end
  if(load_bubble && can_advance) load_bubble<=0;
  if(dm_req) mem_sent<=1;
  if(!can_advance) wv<=0;
  if(can_advance) begin
   wv<=mv;
   if(mv) begin
    wrd<=mrd;wwi<=mwi;wwf<=mwf;wres<=mem_result;
   end
   mv<=ev;mem_sent<=0;
   if(ev) begin
    mres<= (eop==7'h73)?csr_y:alu_y;
    mstore<=eb;mf3<=ef3;mop<=eop;mrd<=erd;
    mwi<=ewi;mwf<=ewf;mload<=eload;mstore_en<=estore;
   end
   ev<=dv && !load_bubble && !redirect;
   if(dv && !load_bubble && !redirect) begin
    dv<=0;epc<=dpc;eimm<=dimm;
    eop<=dop;ef3<=df3;ef7<=df7;ecsr<=di[31:20];er1<=dr1;er2<=dr2;erd<=drd;
    ewi<=dwi;ewf<=dwf;eload<=dload;estore<=dstore;ebranch<=dbranch;ejump<=djump;
    // V2: retain two selected operands instead of all four RF read values.
    // Keep the same capture enable, reset and integer/FP forwarding below.
    if(dop==7'h53) begin
     eda<=fa; edb<=fb;
    end else begin
     eda<=ia;
     if(dop==7'h27) edb<=fb;
     else edb<=ib;
    end
    if(dload) load_bubble<=1; // Mandatory 1-cycle bubble after every load.
   end
   if(redirect) dv<=0; // Branch/jump resolved in EX; discard wrong path.
  end
 end
 end
endmodule
