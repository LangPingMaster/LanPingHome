module CSR(input logic clk,rst,retire,input logic [11:0] addr,output logic [31:0] rd);
 logic [63:0] cycles,instret;
 always_ff @(posedge clk or posedge rst) if(rst) begin cycles<=0;instret<=0;end else begin cycles<=cycles+1; if(retire) instret<=instret+1;end
 always_comb case(addr)
 12'hc00:rd=cycles[31:0];12'hc80:rd=cycles[63:32];
 12'hc02:rd=instret[31:0];12'hc82:rd=instret[63:32];default:rd=0;
 endcase
endmodule
