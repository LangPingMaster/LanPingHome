module LD_filter(input logic [31:0] word,input logic [1:0] ofs,input logic [2:0] f3,output logic [31:0] result);
 logic [31:0] shifted;
 always_comb begin
 shifted=word>>{27'd0,ofs,3'b000};
 case(f3)
 3'b000:result={{24{shifted[7]}},shifted[7:0]};
 3'b001:result={{16{shifted[15]}},shifted[15:0]};
 3'b100:result={24'b0,shifted[7:0]};
 3'b101:result={16'b0,shifted[15:0]};
 default:result=word;
 endcase
 end
endmodule
