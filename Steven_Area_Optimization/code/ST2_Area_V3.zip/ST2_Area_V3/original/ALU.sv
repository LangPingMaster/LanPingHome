`include "MUL_low.sv"
`include "MUL_high_ss.sv"
`include "MUL_high_su.sv"
`include "MUL_high_uu.sv"
`include "MUL_dotp4.sv"
`include "FP_addsub.sv"
`include "FP_min.sv"
`include "FP_max.sv"

module ALU(input logic [31:0] a,b,imm,pc,input logic [6:0] opcode,f7,input logic [2:0] f3,output logic [31:0] y);
 wire [31:0] ml,mh,mhsu,mhu,dotp,fa,fs,fmin,fmax;
 MUL_low mul_i(.a(a),.b(b),.y(ml));MUL_high_ss mulh_i(.a(a),.b(b),.y(mh));MUL_high_su mulhsu_i(.a(a),.b(b),.y(mhsu));MUL_high_uu mulhu_i(.a(a),.b(b),.y(mhu));MUL_dotp4 dotp4_i(.a(a),.b(b),.y(dotp));
 FP_addsub #(.SUB(0)) fadd_i(.a(a),.b(b),.y(fa));FP_addsub #(.SUB(1)) fsub_i(.a(a),.b(b),.y(fs));
 FP_min fmin_i(.a(a),.b(b),.y(fmin));FP_max fmax_i(.a(a),.b(b),.y(fmax));
 logic [31:0] rhs;integer i,cnt;logic signed [9:0] lane;
 logic [4:0] rotate_amount;
 assign rotate_amount = 5'd0 - b[4:0];
 
 always_comb begin
 rhs=(opcode==7'h13)?imm:b;y=32'd0;cnt=0;lane=10'sd0;
 case(opcode)
 7'h37:y=imm;
 7'h17:y=pc+imm;
 7'h6f,7'h67:y=pc+4;
 7'h03,7'h07,7'h23,7'h27:y=a+imm;
 7'h53:case(f7)
 7'b0000000:y=fa;7'b0000100:y=fs;
 7'b0010100:y=(f3==0)?fmin:fmax;default:y=0;
 endcase
 7'h0b:case(f3)
 0:y=dotp;
 1:for(i=0;i<4;i=i+1) begin lane=$signed(a[i*8+:8])+$signed(b[i*8+:8]);y[i*8+:8]=(lane>10'sd127)?8'h7f:((lane< -10'sd128)?8'h80:lane[7:0]);end
 2:for(i=0;i<4;i=i+1) begin lane=$signed(a[i*8+:8])-$signed(b[i*8+:8]);y[i*8+:8]=(lane>10'sd127)?8'h7f:((lane< -10'sd128)?8'h80:lane[7:0]);end
 3:y=(a==32'h80000000)?32'h7fffffff:($signed(a)<0)?-a:a;
 4:y=($signed(a)>32'sd127)?32'd127:($signed(a)< -32'sd128)?32'hffffff80:a;
 default:y=0;endcase
 7'h33,7'h13:begin
 if(opcode==7'h33 && f7==7'h01) case(f3)
 0:y=ml;1:y=mh;2:y=mhsu;3:y=mhu;default:y=0;endcase
 else if(opcode==7'h33 && f7==7'b0110000) case(f3)
 1:y=(a<<b[4:0])|(a>>rotate_amount);
 5:y=(a>>b[4:0])|(a<<rotate_amount);default:y=0;endcase
 else if(opcode==7'h33 && f7==7'b0000101) case(f3)
 4:y=($signed(a)<$signed(b))?a:b;5:y=(a<b)?a:b;
 6:y=($signed(a)>$signed(b))?a:b;7:y=(a>b)?a:b;default:y=0;endcase
 else if(opcode==7'h33 && f7==7'b0010100 && f3==1) y=a|(32'h1<<b[4:0]);
 else if(opcode==7'h33 && f7==7'b0100100 && f3==1) y=a&~(32'h1<<b[4:0]);
 else if(opcode==7'h33 && f7==7'b0100100 && f3==5) y=(a>>b[4:0])&1;
 else if(opcode==7'h13 && f7==7'b0110000 && f3==1) begin
  if(b==32'hffffffff) y=0;
  case(imm[4:0])
  0:begin cnt=0;for(i=31;i>=0;i=i-1) if(!a[i] && cnt==(31-i)) cnt=cnt+1;y=$unsigned(cnt);end
  1:begin cnt=0;for(i=0;i<32;i=i+1) if(!a[i] && cnt==i) cnt=cnt+1;y=$unsigned(cnt);end
  2:begin cnt=0;for(i=0;i<32;i=i+1) cnt=cnt+int'({31'd0,a[i]});y=$unsigned(cnt);end
  default:y=0;endcase
 end
 else case(f3)
 0:y=(opcode==7'h33 && f7==7'h20)?a-rhs:a+rhs;
 1:y=a<<rhs[4:0];
 2:y=($signed(a)<$signed(rhs));3:y=(a<rhs);
 4:y=a^rhs;
 5: begin
   // SRA/SRAI: arithmetic right shift must preserve the sign bit.
   // Do not mix signed and unsigned shifts in a ternary expression.
   if (f7 == 7'h20)
     y = $signed(a) >>> rhs[4:0];
   else
     y = a >> rhs[4:0];
  end
 6:y=a|rhs;7:y=a&rhs;
 endcase
 end
 default:y=0;
 endcase
 end
endmodule
