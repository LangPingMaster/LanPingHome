module FP_addsub #(parameter SUB=0)(input logic [31:0] a,b,output logic [31:0] y);
 logic sa,sb,sbig,ssmall,signr;logic [7:0] ea,eb,ebig,esmall,er;
 logic [26:0] big,small_val,aligned,mag;logic [27:0] sum;
 logic [31:0] bb;integer shift,k;
 logic guard,roundbit,sticky,inc;logic [24:0] rounded;
 always_comb begin
 bb={b[31]^SUB, b[30:0]};
 sa=a[31];sb=bb[31];ea=a[30:23];eb=bb[30:23];
 if ({ea,a[22:0]}>={eb,bb[22:0]}) begin
  ebig=ea;esmall=eb;big={1'b1,a[22:0],3'b0};small_val={1'b1,bb[22:0],3'b0};sbig=sa;ssmall=sb;
 end else begin
  ebig=eb;esmall=ea;big={1'b1,bb[22:0],3'b0};small_val={1'b1,a[22:0],3'b0};sbig=sb;ssmall=sa;
 end
 shift=int'({24'd0,ebig})-int'({24'd0,esmall});aligned=0;
 if(shift==0) aligned=small_val;
 else if(shift<27) begin aligned=small_val>>shift; for(k=0;k<27;k=k+1) if(k<shift) aligned[0]=aligned[0]|small_val[k];end
 else aligned={26'b0,(|small_val)};
 sum=0;signr=sbig;er=ebig;mag=0;
 if(sbig==ssmall) sum={1'b0,big}+{1'b0,aligned};
 else sum={1'b0,big}-{1'b0,aligned};
 if(sum[27]) begin mag=sum[27:1];mag[0]=mag[0]|sum[0];er=ebig+1;end
 else begin
 mag=sum[26:0];
 for(k=0;k<26;k=k+1) if(mag!=0 && !mag[26]) begin mag=mag<<1;er=er-1;end
 end
 guard=mag[2];roundbit=mag[1];sticky=mag[0];inc=guard&&(roundbit||sticky||mag[3]);
 rounded={1'b0,mag[26:3]}+{24'd0,inc};
 if(rounded[24]) begin rounded=rounded>>1;er=er+1;end
 y={signr,er,rounded[22:0]};
 if(sum==0) y=0;
 if(a[30:0]==0) y=bb;
 if(b[30:0]==0) y=a;
 if(a[30:0]==0 && b[30:0]==0) y=0;
 end
endmodule
