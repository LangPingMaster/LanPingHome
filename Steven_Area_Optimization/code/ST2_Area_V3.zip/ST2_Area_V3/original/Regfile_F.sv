module Regfile_F(input logic clk,rst,we,input logic [4:0] ra,rb,wa,input logic [31:0] wd,output logic [31:0] a,b);
 logic [31:0] r[0:31];
 assign a=r[ra]; assign b=r[rb];
 integer i;
 always_ff @(posedge clk or posedge rst) begin
  if (rst) begin
   for (i=0; i<32; i=i+1) r[i] <= 32'b0;
  end else if (we) begin
   r[wa] <= wd;
  end
 end
endmodule
