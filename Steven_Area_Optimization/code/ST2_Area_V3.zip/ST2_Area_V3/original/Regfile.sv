module Regfile(input logic clk,rst,we,input logic [4:0] ra,rb,wa,input logic [31:0] wd,output logic [31:0] a,b);
 logic [31:0] r[0:31];
 assign a=(ra==0)?0:r[ra]; assign b=(rb==0)?0:r[rb];
 integer i;
 always_ff @(posedge clk or posedge rst) begin
  if (rst) begin
   for (i=0; i<32; i=i+1) r[i] <= 32'b0;
  end else if (we && wa!=0) begin
   r[wa] <= wd;
  end
 end
endmodule
