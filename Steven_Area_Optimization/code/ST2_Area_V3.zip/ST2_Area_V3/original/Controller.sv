module Controller(input logic rst,pending,dv,load_bubble,mem_hold,ev,ebranch,ejump,branch_taken,
 output logic advance,fetch_req,redirect);
 assign advance=!mem_hold;
 assign redirect=ev&&(ebranch||ejump)&&branch_taken&&!mem_hold;
 assign fetch_req=!rst&&!pending&&!dv&&!load_bubble&&!mem_hold&&!(ev&&(ebranch||ejump));
endmodule
