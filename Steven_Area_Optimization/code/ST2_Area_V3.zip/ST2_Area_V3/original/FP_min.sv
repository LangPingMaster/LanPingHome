module FP_min(input logic [31:0] a,b,output logic [31:0] y);
 logic less;
 always_comb begin
 less=1'b0; // Default prevents an inferred latch when both operands are zero.
 if(a[30:0]==0 && b[30:0]==0) y=(a[31]||b[31])?32'h80000000:0;
 else begin less=(a[31]!=b[31])?a[31]:(a[31]?(a[30:0]>b[30:0]):(a[30:0]<b[30:0]));y=less?a:b;end
 end
endmodule
