module Decoder(input logic [31:0] inst,output logic [6:0] opcode,output logic [2:0] f3,output logic [6:0] f7,output logic [4:0] rs1,rs2,rd,output logic int_src1,int_src2,fp_src1,fp_src2,int_wr,fp_wr,mem_rd,mem_wr,branch,jump);
 always_comb begin
 opcode=inst[6:0]; f3=inst[14:12]; f7=inst[31:25]; rs1=inst[19:15];rs2=inst[24:20];rd=inst[11:7];
 int_src1=0;int_src2=0;fp_src1=0;fp_src2=0;int_wr=0;fp_wr=0;mem_rd=0;mem_wr=0;branch=0;jump=0;
 case(inst[6:0])
 7'h33,7'h0b:begin int_src1=1;int_src2=1;int_wr=1;end
 7'h13:begin int_src1=1;int_wr=1;end
 7'h03:begin int_src1=1;int_wr=1;mem_rd=1;end
 7'h07:begin int_src1=1;fp_wr=1;mem_rd=1;end
 7'h23:begin int_src1=1;int_src2=1;mem_wr=1;end
 7'h27:begin int_src1=1;fp_src2=1;mem_wr=1;end
 7'h53:begin fp_src1=1;fp_src2=1;fp_wr=1;end
 7'h63:begin int_src1=1;int_src2=1;branch=1;end
 7'h6f:begin int_wr=1;jump=1;end
 7'h67:begin int_src1=1;int_wr=1;jump=1;end
 7'h37,7'h17,7'h73: int_wr=1;
 default: begin
  int_src1=1'b0; // Explicit default; all other outputs already default to zero.
 end
 endcase
 end
endmodule
