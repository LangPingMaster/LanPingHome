module JB_unit(input logic [31:0] pc,a,b,imm,input logic [6:0] opcode,input logic [2:0] f3,output logic taken,output logic [31:0] target);
 always_comb begin
 taken=0;target=pc+imm;
 if(opcode==7'h6f) taken=1;
 else if(opcode==7'h67) begin taken=1;target=(a+imm)&32'hfffffffe;end
 else if(opcode==7'h63) case(f3)
 0:taken=(a==b);1:taken=(a!=b);4:taken=($signed(a)<$signed(b));5:taken=($signed(a)>=$signed(b));
 6:taken=(a<b);7:taken=(a>=b);default:taken=0;
 endcase
 end
endmodule
