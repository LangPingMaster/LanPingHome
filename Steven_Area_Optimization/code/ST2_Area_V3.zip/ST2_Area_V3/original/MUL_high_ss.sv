module MUL_high_ss(input logic signed [31:0] a,b,output logic [31:0] y);
 wire signed [63:0] p=a*b;assign y=p[63:32];endmodule
