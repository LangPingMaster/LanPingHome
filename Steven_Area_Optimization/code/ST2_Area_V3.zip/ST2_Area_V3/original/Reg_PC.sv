module Reg_PC(input logic clk,rst,en,input logic [31:0] next_pc,output logic [31:0] pc);
 always_ff @(posedge clk or posedge rst) if(rst) pc<=0; else if(en) pc<=next_pc;
endmodule
