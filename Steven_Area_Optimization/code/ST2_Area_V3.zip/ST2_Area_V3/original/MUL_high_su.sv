module MUL_high_su(input logic signed [31:0] a,input logic [31:0] b,output logic [31:0] y);
 wire signed [63:0] p=$signed({{32{a[31]}},a})*$signed({32'b0,b});assign y=p[63:32];endmodule
