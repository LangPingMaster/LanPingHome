module MUL_high_uu(input logic [31:0] a,b,output logic [31:0] y);
 wire [63:0] p=a*b;assign y=p[63:32];endmodule
