module MUL_dotp4(input logic [31:0] a,b,output logic [31:0] y);
 wire signed [15:0] p0=$signed(a[7:0])*$signed(b[7:0]);
 wire signed [15:0] p1=$signed(a[15:8])*$signed(b[15:8]);
 wire signed [15:0] p2=$signed(a[23:16])*$signed(b[23:16]);
 wire signed [15:0] p3=$signed(a[31:24])*$signed(b[31:24]);
 assign y={{16{p0[15]}},p0}+{{16{p1[15]}},p1}+{{16{p2[15]}},p2}+{{16{p3[15]}},p3};
endmodule
