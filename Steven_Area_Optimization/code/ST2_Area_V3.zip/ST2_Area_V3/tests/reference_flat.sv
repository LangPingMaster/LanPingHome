module ref_Controller(input logic rst,pending,dv,load_bubble,mem_hold,ev,ebranch,ejump,branch_taken,
 output logic advance,fetch_req,redirect);
 assign advance=!mem_hold;
 assign redirect=ev&&(ebranch||ejump)&&branch_taken&&!mem_hold;
 assign fetch_req=!rst&&!pending&&!dv&&!load_bubble&&!mem_hold&&!(ev&&(ebranch||ejump));
endmodule

module ref_FP_addsub #(parameter SUB=0)(input logic [31:0] a,b,output logic [31:0] y);
 logic sa,sb,sbig,ssmall,signr;logic [7:0] ea,eb,ebig,esmall,er;
 logic [26:0] big,small_val,aligned,mag;logic [27:0] sum;
 logic [31:0] bb;integer shift,k;
 logic guard,roundbit,sticky,inc;logic [24:0] rounded;
 always_comb begin
 bb={b[31]^SUB, b[30:0]};
 sa=a[31];sb=bb[31];ea=a[30:23];eb=bb[30:23];
 if ({ea,a[22:0]}>={eb,bb[22:0]}) begin
  ebig=ea;esmall=eb;big={1'b1,a[22:0],3'b0};small_val={1'b1,bb[22:0],3'b0};sbig=sa;ssmall=sb;
 end else begin
  ebig=eb;esmall=ea;big={1'b1,bb[22:0],3'b0};small_val={1'b1,a[22:0],3'b0};sbig=sb;ssmall=sa;
 end
 shift=int'({24'd0,ebig})-int'({24'd0,esmall});aligned=0;
 if(shift==0) aligned=small_val;
 else if(shift<27) begin aligned=small_val>>shift; for(k=0;k<27;k=k+1) if(k<shift) aligned[0]=aligned[0]|small_val[k];end
 else aligned={26'b0,(|small_val)};
 sum=0;signr=sbig;er=ebig;mag=0;
 if(sbig==ssmall) sum={1'b0,big}+{1'b0,aligned};
 else sum={1'b0,big}-{1'b0,aligned};
 if(sum[27]) begin mag=sum[27:1];mag[0]=mag[0]|sum[0];er=ebig+1;end
 else begin
 mag=sum[26:0];
 for(k=0;k<26;k=k+1) if(mag!=0 && !mag[26]) begin mag=mag<<1;er=er-1;end
 end
 guard=mag[2];roundbit=mag[1];sticky=mag[0];inc=guard&&(roundbit||sticky||mag[3]);
 rounded={1'b0,mag[26:3]}+{24'd0,inc};
 if(rounded[24]) begin rounded=rounded>>1;er=er+1;end
 y={signr,er,rounded[22:0]};
 if(sum==0) y=0;
 if(a[30:0]==0) y=bb;
 if(b[30:0]==0) y=a;
 if(a[30:0]==0 && b[30:0]==0) y=0;
 end
endmodule

module ref_Decoder(input logic [31:0] inst,output logic [6:0] opcode,output logic [2:0] f3,output logic [6:0] f7,output logic [4:0] rs1,rs2,rd,output logic int_src1,int_src2,fp_src1,fp_src2,int_wr,fp_wr,mem_rd,mem_wr,branch,jump);
 always_comb begin
 opcode=inst[6:0]; f3=inst[14:12]; f7=inst[31:25]; rs1=inst[19:15];rs2=inst[24:20];rd=inst[11:7];
 int_src1=0;int_src2=0;fp_src1=0;fp_src2=0;int_wr=0;fp_wr=0;mem_rd=0;mem_wr=0;branch=0;jump=0;
 case(inst[6:0])
 7'h33,7'h0b:begin int_src1=1;int_src2=1;int_wr=1;end
 7'h13:begin int_src1=1;int_wr=1;end
 7'h03:begin int_src1=1;int_wr=1;mem_rd=1;end
 7'h07:begin int_src1=1;fp_wr=1;mem_rd=1;end
 7'h23:begin int_src1=1;int_src2=1;mem_wr=1;end
 7'h27:begin int_src1=1;fp_src2=1;mem_wr=1;end
 7'h53:begin fp_src1=1;fp_src2=1;fp_wr=1;end
 7'h63:begin int_src1=1;int_src2=1;branch=1;end
 7'h6f:begin int_wr=1;jump=1;end
 7'h67:begin int_src1=1;int_wr=1;jump=1;end
 7'h37,7'h17,7'h73: int_wr=1;
 default: begin
  int_src1=1'b0; // Explicit default; all other outputs already default to zero.
 end
 endcase
 end
endmodule

module ref_MUL_high_su(input logic signed [31:0] a,input logic [31:0] b,output logic [31:0] y);
 wire signed [63:0] p=$signed({{32{a[31]}},a})*$signed({32'b0,b});assign y=p[63:32];endmodule

module ref_Regfile(input logic clk,rst,we,input logic [4:0] ra,rb,wa,input logic [31:0] wd,output logic [31:0] a,b);
 logic [31:0] r[0:31];
 assign a=(ra==0)?0:r[ra]; assign b=(rb==0)?0:r[rb];
 integer i;
 always_ff @(posedge clk or posedge rst) begin
  if (rst) begin
   for (i=0; i<32; i=i+1) r[i] <= 32'b0;
  end else if (we && wa!=0) begin
   r[wa] <= wd;
  end
 end
endmodule

module ref_MUL_dotp4(input logic [31:0] a,b,output logic [31:0] y);
 wire signed [15:0] p0=$signed(a[7:0])*$signed(b[7:0]);
 wire signed [15:0] p1=$signed(a[15:8])*$signed(b[15:8]);
 wire signed [15:0] p2=$signed(a[23:16])*$signed(b[23:16]);
 wire signed [15:0] p3=$signed(a[31:24])*$signed(b[31:24]);
 assign y={{16{p0[15]}},p0}+{{16{p1[15]}},p1}+{{16{p2[15]}},p2}+{{16{p3[15]}},p3};
endmodule

module ref_MUL_high_ss(input logic signed [31:0] a,b,output logic [31:0] y);
 wire signed [63:0] p=a*b;assign y=p[63:32];endmodule

module ref_CSR(input logic clk,rst,retire,input logic [11:0] addr,output logic [31:0] rd);
 logic [63:0] cycles,instret;
 always_ff @(posedge clk or posedge rst) if(rst) begin cycles<=0;instret<=0;end else begin cycles<=cycles+1; if(retire) instret<=instret+1;end
 always_comb case(addr)
 12'hc00:rd=cycles[31:0];12'hc80:rd=cycles[63:32];
 12'hc02:rd=instret[31:0];12'hc82:rd=instret[63:32];default:rd=0;
 endcase
endmodule

module ref_JB_unit(input logic [31:0] pc,a,b,imm,input logic [6:0] opcode,input logic [2:0] f3,output logic taken,output logic [31:0] target);
 always_comb begin
 taken=0;target=pc+imm;
 if(opcode==7'h6f) taken=1;
 else if(opcode==7'h67) begin taken=1;target=(a+imm)&32'hfffffffe;end
 else if(opcode==7'h63) case(f3)
 0:taken=(a==b);1:taken=(a!=b);4:taken=($signed(a)<$signed(b));5:taken=($signed(a)>=$signed(b));
 6:taken=(a<b);7:taken=(a>=b);default:taken=0;
 endcase
 end
endmodule

module ref_FP_max(input logic [31:0] a,b,output logic [31:0] y);
 logic greater;
 always_comb begin
 greater=1'b0; // Default prevents an inferred latch when both operands are zero.
 if(a[30:0]==0 && b[30:0]==0) y=(a[31]&&b[31])?32'h80000000:0;
 else begin greater=(a[31]!=b[31])?b[31]:(a[31]?(a[30:0]<b[30:0]):(a[30:0]>b[30:0]));y=greater?a:b;end
 end
endmodule

module ref_MUL_high_uu(input logic [31:0] a,b,output logic [31:0] y);
 wire [63:0] p=a*b;assign y=p[63:32];endmodule


module ref_ALU(input logic [31:0] a,b,imm,pc,input logic [6:0] opcode,f7,input logic [2:0] f3,output logic [31:0] y);
 wire [31:0] ml,mh,mhsu,mhu,dotp,fa,fs,fmin,fmax;
 ref_MUL_low mul_i(.a(a),.b(b),.y(ml));ref_MUL_high_ss mulh_i(.a(a),.b(b),.y(mh));ref_MUL_high_su mulhsu_i(.a(a),.b(b),.y(mhsu));ref_MUL_high_uu mulhu_i(.a(a),.b(b),.y(mhu));ref_MUL_dotp4 dotp4_i(.a(a),.b(b),.y(dotp));
 ref_FP_addsub #(.SUB(0)) fadd_i(.a(a),.b(b),.y(fa));ref_FP_addsub #(.SUB(1)) fsub_i(.a(a),.b(b),.y(fs));
 ref_FP_min fmin_i(.a(a),.b(b),.y(fmin));ref_FP_max fmax_i(.a(a),.b(b),.y(fmax));
 logic [31:0] rhs;integer i,cnt;logic signed [9:0] lane;
 logic [4:0] rotate_amount;
 assign rotate_amount = 5'd0 - b[4:0];
 
 always_comb begin
 rhs=(opcode==7'h13)?imm:b;y=32'd0;cnt=0;lane=10'sd0;
 case(opcode)
 7'h37:y=imm;
 7'h17:y=pc+imm;
 7'h6f,7'h67:y=pc+4;
 7'h03,7'h07,7'h23,7'h27:y=a+imm;
 7'h53:case(f7)
 7'b0000000:y=fa;7'b0000100:y=fs;
 7'b0010100:y=(f3==0)?fmin:fmax;default:y=0;
 endcase
 7'h0b:case(f3)
 0:y=dotp;
 1:for(i=0;i<4;i=i+1) begin lane=$signed(a[i*8+:8])+$signed(b[i*8+:8]);y[i*8+:8]=(lane>10'sd127)?8'h7f:((lane< -10'sd128)?8'h80:lane[7:0]);end
 2:for(i=0;i<4;i=i+1) begin lane=$signed(a[i*8+:8])-$signed(b[i*8+:8]);y[i*8+:8]=(lane>10'sd127)?8'h7f:((lane< -10'sd128)?8'h80:lane[7:0]);end
 3:y=(a==32'h80000000)?32'h7fffffff:($signed(a)<0)?-a:a;
 4:y=($signed(a)>32'sd127)?32'd127:($signed(a)< -32'sd128)?32'hffffff80:a;
 default:y=0;endcase
 7'h33,7'h13:begin
 if(opcode==7'h33 && f7==7'h01) case(f3)
 0:y=ml;1:y=mh;2:y=mhsu;3:y=mhu;default:y=0;endcase
 else if(opcode==7'h33 && f7==7'b0110000) case(f3)
 1:y=(a<<b[4:0])|(a>>rotate_amount);
 5:y=(a>>b[4:0])|(a<<rotate_amount);default:y=0;endcase
 else if(opcode==7'h33 && f7==7'b0000101) case(f3)
 4:y=($signed(a)<$signed(b))?a:b;5:y=(a<b)?a:b;
 6:y=($signed(a)>$signed(b))?a:b;7:y=(a>b)?a:b;default:y=0;endcase
 else if(opcode==7'h33 && f7==7'b0010100 && f3==1) y=a|(32'h1<<b[4:0]);
 else if(opcode==7'h33 && f7==7'b0100100 && f3==1) y=a&~(32'h1<<b[4:0]);
 else if(opcode==7'h33 && f7==7'b0100100 && f3==5) y=(a>>b[4:0])&1;
 else if(opcode==7'h13 && f7==7'b0110000 && f3==1) begin
  if(b==32'hffffffff) y=0;
  case(imm[4:0])
  0:begin cnt=0;for(i=31;i>=0;i=i-1) if(!a[i] && cnt==(31-i)) cnt=cnt+1;y=$unsigned(cnt);end
  1:begin cnt=0;for(i=0;i<32;i=i+1) if(!a[i] && cnt==i) cnt=cnt+1;y=$unsigned(cnt);end
  2:begin cnt=0;for(i=0;i<32;i=i+1) cnt=cnt+int'({31'd0,a[i]});y=$unsigned(cnt);end
  default:y=0;endcase
 end
 else case(f3)
 0:y=(opcode==7'h33 && f7==7'h20)?a-rhs:a+rhs;
 1:y=a<<rhs[4:0];
 2:y=($signed(a)<$signed(rhs));3:y=(a<rhs);
 4:y=a^rhs;
 5: begin
   // SRA/SRAI: arithmetic right shift must preserve the sign bit.
   // Do not mix signed and unsigned shifts in a ternary expression.
   if (f7 == 7'h20)
     y = $signed(a) >>> rhs[4:0];
   else
     y = a >> rhs[4:0];
  end
 6:y=a|rhs;7:y=a&rhs;
 endcase
 end
 default:y=0;
 endcase
 end
endmodule

module ref_LD_filter(input logic [31:0] word,input logic [1:0] ofs,input logic [2:0] f3,output logic [31:0] result);
 logic [31:0] shifted;
 always_comb begin
 shifted=word>>{27'd0,ofs,3'b000};
 case(f3)
 3'b000:result={{24{shifted[7]}},shifted[7:0]};
 3'b001:result={{16{shifted[15]}},shifted[15:0]};
 3'b100:result={24'b0,shifted[7:0]};
 3'b101:result={16'b0,shifted[15:0]};
 default:result=word;
 endcase
 end
endmodule

module ref_Regfile_F(input logic clk,rst,we,input logic [4:0] ra,rb,wa,input logic [31:0] wd,output logic [31:0] a,b);
 logic [31:0] r[0:31];
 assign a=r[ra]; assign b=r[rb];
 integer i;
 always_ff @(posedge clk or posedge rst) begin
  if (rst) begin
   for (i=0; i<32; i=i+1) r[i] <= 32'b0;
  end else if (we) begin
   r[wa] <= wd;
  end
 end
endmodule



module ref_top(
 input logic clk,rst,im_valid,input logic [31:0] im_read_data,
 output logic im_req,output logic [31:0] im_addr,
 input logic dm_valid,input logic [31:0] dm_read_data,
 output logic dm_req,dm_WEB,output logic [31:0] dm_bit_en,dm_addr,dm_write_data
);
 // Five pipeline stages: IF request -> ID -> EX -> MEM -> WB.
 logic [31:0] pc,next_pc;logic pc_en;
 ref_Reg_PC pc_i(.clk(clk),.rst(rst),.en(pc_en),.next_pc(next_pc),.pc(pc));
 assign im_addr=pc;
 logic pending,dv,ev,mv,wv,mem_sent,load_bubble;
 logic [31:0] di,dpc,epc,eimm,mres,mstore,wres;
 logic [6:0] dop,df7,eop,ef7,mop;logic [2:0] df3,ef3,mf3;
 logic [4:0] dr1,dr2,drd,er1,er2,erd,mrd,wrd;
 logic ds1,ds2,dfs1,dfs2,dwi,dwf,dload,dstore,dbranch,djump;
 logic ewi,ewf,eload,estore,ebranch,ejump,mwi,mwf,mload,mstore_en,wwi,wwf;
 logic [31:0] dimm,ia,ib,fa,fb,eda,edb,era,erb,ea,eb,alu_y,branch_target;
 logic branch_taken,redirect,mem_hold,can_advance,fetch_ok;
 logic [31:0] csr_y,load_y,mem_result;
 logic [11:0] ecsr;
 ref_Decoder dec(.inst(di),.opcode(dop),.f3(df3),.f7(df7),.rs1(dr1),.rs2(dr2),.rd(drd),.int_src1(ds1),.int_src2(ds2),.fp_src1(dfs1),.fp_src2(dfs2),.int_wr(dwi),.fp_wr(dwf),.mem_rd(dload),.mem_wr(dstore),.branch(dbranch),.jump(djump));
 ref_Imm_ext ie(.inst(di),.imm(dimm));
 ref_Regfile VSD_REG_FILE_I(.clk(clk),.rst(rst),.we(wv&&wwi),.ra(dr1),.rb(dr2),.wa(wrd),.wd(wres),.a(ia),.b(ib));
 ref_Regfile_F VSD_REG_FILE_F(.clk(clk),.rst(rst),.we(wv&&wwf),.ra(dr1),.rb(dr2),.wa(wrd),.wd(wres),.a(fa),.b(fb));
 // EX bypass: newest MEM ref_ALU result, then WB. Never bypass an unfinished load.
 always_comb begin
 ea=eda;eb=edb;
 if(eop==7'h53) begin ea=era;eb=erb;end
 else if(eop==7'h27) eb=erb;
 if(eop==7'h53) begin
  if(mv&&mwf&&!mload&&mrd==er1) ea=mres;
  else if(wv&&wwf&&wrd==er1) ea=wres;
  if(mv&&mwf&&!mload&&mrd==er2) eb=mres;
  else if(wv&&wwf&&wrd==er2) eb=wres;
 end else begin
  if(ev&&er1!=0 && eop!=7'h6f && eop!=7'h37 && eop!=7'h17 && eop!=7'h73) begin
   if(mv&&mwi&&!mload&&mrd==er1) ea=mres;
   else if(wv&&wwi&&wrd==er1) ea=wres;
  end
  if(eop==7'h27) begin
   if(mv&&mwf&&!mload&&mrd==er2) eb=mres;
   else if(wv&&wwf&&wrd==er2) eb=wres;
  end else if(er2!=0 && (eop==7'h33||eop==7'h0b||eop==7'h23||eop==7'h63)) begin
   if(mv&&mwi&&!mload&&mrd==er2) eb=mres;
   else if(wv&&wwi&&wrd==er2) eb=wres;
  end
 end
 end
 ref_ALU alu_i(.a(ea),.b(eb),.imm(eimm),.pc(epc),.opcode(eop),.f7(ef7),.f3(ef3),.y(alu_y));
 ref_JB_unit jb_i(.pc(epc),.a(ea),.b(eb),.imm(eimm),.opcode(eop),.f3(ef3),.taken(branch_taken),.target(branch_target));
 ref_Controller ctrl_i(.rst(rst),.pending(pending),.dv(dv),.load_bubble(load_bubble),.mem_hold(mem_hold),.ev(ev),.ebranch(ebranch),.ejump(ejump),.branch_taken(branch_taken),.advance(can_advance),.fetch_req(fetch_ok),.redirect(redirect));
 ref_CSR csr_i(.clk(clk),.rst(rst),.retire(wv),.addr(ecsr),.rd(csr_y));
 ref_LD_filter ld_i(.word(dm_read_data),.ofs(mres[1:0]),.f3(mf3),.result(load_y));
always_comb begin
    if (mload) begin
        if (mop == 7'h07)
            mem_result = dm_read_data;  // FLW
        else
            mem_result = load_y;        // 整數 Load
    end
    else begin
        mem_result = mres;              // ref_ALU 結果
    end
end
 // Data-memory request: one-cycle pulse, keep payload stable until valid.
 assign dm_req=mv&&(mload||mstore_en)&&!mem_sent;
 assign dm_WEB=!mstore_en;
 assign dm_addr=mres;
 always_comb begin
 dm_bit_en=32'hffffffff;dm_write_data=mstore;
 case(mf3)
 3'b000:begin dm_bit_en=~(32'hff<<{27'd0,mres[1:0],3'b000});dm_write_data=mstore<<{27'd0,mres[1:0],3'b000};end
 3'b001:begin dm_bit_en=~(32'hffff<<{27'd0,mres[1:0],3'b000});dm_write_data=mstore<<{27'd0,mres[1:0],3'b000};end
 default:begin dm_bit_en=32'h00000000;dm_write_data=mstore;end
 endcase
 if(!mstore_en) dm_bit_en=32'hffffffff;
 end
 assign mem_hold=mv&&(mload||mstore_en)&&!(mem_sent&&dm_valid);
 
 // No new request while a previous fetch is outstanding. The ID slot must be free.
 
 assign im_req=fetch_ok;
 assign pc_en=im_req||redirect;
 assign next_pc=redirect?branch_target:(pc+4);
 // ID -> EX operands; WB bypass fixes read-during-write ambiguity.
 always_ff @(posedge clk or posedge rst) begin
 if(rst) begin
  pending<=0;dv<=0;ev<=0;mv<=0;wv<=0;mem_sent<=0;load_bubble<=0;
  di<=0;dpc<=0;epc<=0;eimm<=0;eda<=0;edb<=0;era<=0;erb<=0;
  eop<=0;ef7<=0;ef3<=0;ecsr<=0;er1<=0;er2<=0;erd<=0;
  ewi<=0;ewf<=0;eload<=0;estore<=0;ebranch<=0;ejump<=0;
  mres<=0;mstore<=0;mf3<=0;mop<=0;mrd<=0;mwi<=0;mwf<=0;mload<=0;mstore_en<=0;
  wrd<=0;wres<=0;wwi<=0;wwf<=0;
 end else begin
  // WB always retires exactly once; it cannot be held by a MEM stall.
  if(im_req) pending<=1;
  if(im_valid&&pending) begin
   pending<=0;
   if(!redirect) begin dv<=1;di<=im_read_data;dpc<=pc-4;end
  end
  if(load_bubble && can_advance) load_bubble<=0;
  if(dm_req) mem_sent<=1;
  if(!can_advance) wv<=0;
  if(can_advance) begin
   wv<=mv;
   if(mv) begin
    wrd<=mrd;wwi<=mwi;wwf<=mwf;wres<=mem_result;
   end
   mv<=ev;mem_sent<=0;
   if(ev) begin
    mres<= (eop==7'h73)?csr_y:alu_y;
    mstore<=eb;mf3<=ef3;mop<=eop;mrd<=erd;
    mwi<=ewi;mwf<=ewf;mload<=eload;mstore_en<=estore;
   end
   ev<=dv && !load_bubble && !redirect;
   if(dv && !load_bubble && !redirect) begin
    dv<=0;epc<=dpc;eimm<=dimm;
    eop<=dop;ef3<=df3;ef7<=df7;ecsr<=di[31:20];er1<=dr1;er2<=dr2;erd<=drd;
    ewi<=dwi;ewf<=dwf;eload<=dload;estore<=dstore;ebranch<=dbranch;ejump<=djump;
    eda<=ia;edb<=ib;era<=fa;erb<=fb;
    if(dload) load_bubble<=1; // Mandatory 1-cycle bubble after every load.
   end
   if(redirect) dv<=0; // Branch/jump resolved in EX; discard wrong path.
  end
 end
 end
endmodule

module ref_FP_min(input logic [31:0] a,b,output logic [31:0] y);
 logic less;
 always_comb begin
 less=1'b0; // Default prevents an inferred latch when both operands are zero.
 if(a[30:0]==0 && b[30:0]==0) y=(a[31]||b[31])?32'h80000000:0;
 else begin less=(a[31]!=b[31])?a[31]:(a[31]?(a[30:0]>b[30:0]):(a[30:0]<b[30:0]));y=less?a:b;end
 end
endmodule

module ref_Reg_PC(input logic clk,rst,en,input logic [31:0] next_pc,output logic [31:0] pc);
 always_ff @(posedge clk or posedge rst) if(rst) pc<=0; else if(en) pc<=next_pc;
endmodule

module ref_Imm_ext(input logic [31:0] inst,output logic [31:0] imm);
 always_comb case(inst[6:0])
 7'b0100011,7'b0100111:imm={{20{inst[31]}},inst[31:25],inst[11:7]};
 7'b1100011:imm={{19{inst[31]}},inst[31],inst[7],inst[30:25],inst[11:8],1'b0};
 7'b0110111,7'b0010111:imm={inst[31:12],12'b0};
 7'b1101111:imm={{11{inst[31]}},inst[31],inst[19:12],inst[20],inst[30:21],1'b0};
 default:imm={{20{inst[31]}},inst[31:20]};
 endcase
endmodule

module ref_MUL_low(input logic [31:0] a,b,output logic [31:0] y);assign y=a*b;endmodule
