`timescale 1ns/1ps
`include "reference_flat.sv"
`include "top.sv"
module equivalence_tb;
 logic clk=0,rst=1,im_valid=0,dm_valid=0;
 logic [31:0] im_read_data=0,dm_read_data=0;
 wire oq,odq,ow,cq,cdq,cw;wire [31:0] oa,oda,obe,odw,ca,cda,cbe,cdw;
 ref_top refcpu(.clk(clk),.rst(rst),.im_valid(im_valid),.im_read_data(im_read_data),.im_req(oq),.im_addr(oa),.dm_valid(dm_valid),.dm_read_data(dm_read_data),.dm_req(odq),.dm_WEB(ow),.dm_bit_en(obe),.dm_addr(oda),.dm_write_data(odw));
 top newcpu(.clk(clk),.rst(rst),.im_valid(im_valid),.im_read_data(im_read_data),.im_req(cq),.im_addr(ca),.dm_valid(dm_valid),.dm_read_data(dm_read_data),.dm_req(cdq),.dm_WEB(cw),.dm_bit_en(cbe),.dm_addr(cda),.dm_write_data(cdw));
 logic [31:0] a=0,b=0,imm=0,pc=0;logic [6:0] opcode=0,f7=0;logic [2:0] f3=0;
 wire [31:0] oldalu,newalu,oldadd,newadd,oldsub,newsub;
 ref_ALU ar(.a(a),.b(b),.imm(imm),.pc(pc),.opcode(opcode),.f7(f7),.f3(f3),.y(oldalu));
 ALU ac(.a(a),.b(b),.imm(imm),.pc(pc),.opcode(opcode),.f7(f7),.f3(f3),.y(newalu));
 ref_FP_addsub #(.SUB(0)) far(.a(a),.b(b),.y(oldadd));
 FP_addsub #(.SUB(0)) fac(.a(a),.b(b),.y(newadd));
 ref_FP_addsub #(.SUB(1)) fsr(.a(a),.b(b),.y(oldsub));
 FP_addsub #(.SUB(1)) fsc(.a(a),.b(b),.y(newsub));
 always #5 clk=~clk;
 integer i;integer seed=20261025;integer dummy;
 initial begin
  dummy=$urandom(seed);
  repeat(3) @(negedge clk);
  rst=0;
  for(i=0;i<20000;i=i+1) begin
   @(negedge clk);
   a=$urandom;b=$urandom;imm=$urandom;pc=$urandom;
   opcode=$urandom;f7=$urandom;f3=$urandom;
   case(i%8)
    0:begin opcode=7'h0b;f3=0;end
    1:begin opcode=7'h13;f7=7'h60;f3=1;imm=i%3;end
    2:begin opcode=7'h33;f7=1;f3=i%4;end
    3:begin opcode=7'h53;f7=0;end
    4:begin opcode=7'h53;f7=4;end
    default:begin end
   endcase
   if(i%13==0) a=0;
   if(i%17==0) b=a;
   im_valid=$urandom;dm_valid=$urandom;im_read_data=$urandom;dm_read_data=$urandom;
   #1;
   if(oldalu!==newalu || oldadd!==newadd || oldsub!==newsub)
    $fatal(1,"Combinational mismatch i=%0d a=%h b=%h old=%h new=%h",i,a,b,oldalu,newalu);
   if({oq,oa,odq,ow,obe,oda,odw}!=={cq,ca,cdq,cw,cbe,cda,cdw})
    $fatal(1,"CPU visible-port mismatch i=%0d",i);
  end
  $display("PASS: 20000 differential samples. Not official HW2/STA/SYN proof.");$finish;
 end
endmodule
