"""Two-state arithmetic/state-transform model checks; NOT HDL simulation or formal proof."""
import random,json
R=random.Random(20261025);MASK=(1<<32)-1
signed=lambda x,n:x-(1<<n) if x&(1<<(n-1)) else x

def norm_old(m,e):
 for _ in range(26):
  if m and not(m&(1<<26)):m=(m<<1)&((1<<27)-1);e=(e-1)&255
 return m,e

def norm_new(m,e):
 if not m:return m,e
 n=0
 for k in [16,8,4,2,1]:
  if m>>(27-k)==0:m=(m<<k)&((1<<27)-1);n+=k
 return m,(e-n)&255

# Verify all byte products and extreme sum combinations.
for a in range(-128,128):
 for b in range(-128,128):assert -32768<=a*b<=32767
for i in range(100000):
 a=R.getrandbits(32);b=R.getrandbits(32)
 ps=[signed((a>>(8*j))&255,8)*signed((b>>(8*j))&255,8) for j in range(4)]
 pair=[ps[0]+ps[1],ps[2]+ps[3]]
 assert all(-(1<<16)<=x<(1<<16) for x in pair)
 total=pair[0]+pair[1];assert -(1<<17)<=total<(1<<17)
 assert sum(x&MASK for x in ps)&MASK==total&MASK
 # Count operations narrowed to six bits.
 for mode in range(3):
  old=0;new=0
  order=range(31,-1,-1) if mode==0 else range(32)
  for j in order:
   if mode==2:old+=(a>>j)&1;new=(new+((a>>j)&1))&63
   else:
    target=31-j if mode==0 else j
    if not((a>>j)&1) and old==target:old+=1
    if not((a>>j)&1) and new==target:new=(new+1)&63
  assert old==new
for i in range(1<<18):assert norm_old(i,0)==norm_new(i,0)
for i in range(100000):
 m=R.getrandbits(27);e=R.randrange(256);assert norm_old(m,e)==norm_new(m,e)
# Directed all possible leading-one positions and all exponent values.
for i in range(27):
 for e in range(256):assert norm_old(1<<i,e)==norm_new(1<<i,e)

def fp(a,b,sub,norm):
 bb=b^(sub<<31);sa=a>>31;sb=bb>>31;ea=(a>>23)&255;eb=(bb>>23)&255
 aa=a&0x7fffff;bf=bb&0x7fffff
 if (ea,aa)>=(eb,bf):big=((1<<23)|aa)<<3;small=((1<<23)|bf)<<3;ebig=ea;esmall=eb;sg=sa;ss=sb
 else:big=((1<<23)|bf)<<3;small=((1<<23)|aa)<<3;ebig=eb;esmall=ea;sg=sb;ss=sa
 shift=ebig-esmall
 if shift==0:al=small
 elif shift<27:al=(small>>shift)|int(bool(small&((1<<shift)-1)))
 else:al=int(bool(small))
 sm=big+al if sg==ss else big-al
 sm&=(1<<28)-1
 if sm&(1<<27):m=(sm>>1)|(sm&1);e=(ebig+1)&255
 else:m,e=norm(sm&((1<<27)-1),ebig)
 inc=bool(m&4) and bool((m&3)|(m&8));rd=(m>>3)+int(inc)
 if rd&(1<<24):rd>>=1;e=(e+1)&255
 y=(sg<<31)|(e<<23)|(rd&0x7fffff)
 if sm==0:y=0
 if a&0x7fffffff==0:y=bb
 if b&0x7fffffff==0:y=a
 if a&0x7fffffff==0 and b&0x7fffffff==0:y=0
 return y
edge=[0,0x80000000,0x3f800000,0xbf800000,0x3f800001,0x33800000,0x34000000,0x7f7fffff,0x00800000,0x3fffffff]
for a in edge:
 for b in edge:
  for sub in [0,1]:assert fp(a,b,sub,norm_old)==fp(a,b,sub,norm_new)
for _ in range(100000):
 a=R.getrandbits(32);b=R.getrandbits(32)
 for sub in [0,1]:assert fp(a,b,sub,norm_old)==fp(a,b,sub,norm_new)
# Random ID/EX state transitions: reset, capture and hold use same enables.
old=[0]*4;new=[0]*2;op=0
for _ in range(100000):
 reset=R.randrange(50)==0;capture=bool(R.getrandbits(1));dop=R.choice([0x53,0x27,0x03,0x07,0x33,0x0b,0x63,0x73])
 vals=[R.getrandbits(32) for _ in range(4)]
 if reset:old=[0]*4;new=[0]*2;op=0
 elif capture:
  old=vals;op=dop
  new=[vals[2] if dop==0x53 else vals[0],vals[3] if dop in (0x53,0x27) else vals[1]]
 expected=[old[2] if op==0x53 else old[0],old[3] if op in (0x53,0x27) else old[1]]
 assert new==expected
print(json.dumps({'type':'Python two-state transformation model checks; not RTL simulation','status':'PASS','seed':20261025,'byte_product_range_cases':65536,'dotp_random_cases':100000,'count_random_cases_per_operation':100000,'normalization_small_exhaustive_cases':262144,'normalization_random_cases':100000,'normalization_single_one_all_exponents':6912,'fp_add_sub_directed_cases':200,'fp_add_sub_random_cases':200000,'pipeline_selection_state_steps':100000,'hdl_simulation':'NOT RUN','formal_equivalence':'NOT RUN','official_regression':'NOT RUN','synthesis_STA_Superlint':'NOT RUN'},indent=2))
